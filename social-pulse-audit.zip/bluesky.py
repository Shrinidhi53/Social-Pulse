
import json
from datetime import datetime

import httpx
from sqlmodel import Session, select

from app.models import SocialRecord

SEARCH_URL = (
    "https://api.bsky.app/xrpc/app.bsky.feed.searchPosts"
)

QUERIES = [
    '"Tata STRIVE"',
    '"skill development" India',
    '"vocational training" India',
    'employability India',
]


def parse_datetime(value):
    if not value:
        return None

    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def collect_bluesky(session: Session) -> dict:
    fetched = 0
    saved = 0
    skipped = 0
    errors = []

    with httpx.Client(timeout=25) as client:
        for query in QUERIES:
            try:
                response = client.get(
                    SEARCH_URL,
                    params={
                        "q": query,
                        "sort": "latest",
                        "limit": 10,
                        "lang": "en",
                    },
                    headers={
                        "User-Agent": "SocialPulse/0.1"
                    },
                )
                response.raise_for_status()
                posts = response.json().get("posts", [])

            except (httpx.HTTPError, ValueError) as exc:
                errors.append({
                    "query": query,
                    "error": f"{type(exc).__name__}: {exc}",
                })
                continue

            fetched += len(posts)

            for post in posts:
                uri = post.get("uri")
                record_data = post.get("record", {})
                text = record_data.get("text", "")
                author_data = post.get("author", {})
                handle = author_data.get("handle")
                did = author_data.get("did")
                rkey = uri.rsplit("/", 1)[-1] if uri else None

                if not uri or not text:
                    skipped += 1
                    continue

                existing = session.exec(
                    select(SocialRecord).where(
                        SocialRecord.source == "bluesky",
                        SocialRecord.external_id == uri,
                    )
                ).first()

                if existing:
                    skipped += 1
                    continue

                profile = handle or did
                post_url = (
                    f"https://bsky.app/profile/{profile}/post/{rkey}"
                    if profile and rkey
                    else None
                )

                created_at = (
                    record_data.get("createdAt")
                    or post.get("indexedAt")
                )

                social_record = SocialRecord(
                    source="bluesky",
                    record_type="social_post",
                    external_id=uri,
                    text=text,
                    url=post_url,
                    author=handle or did,
                    published_at=parse_datetime(created_at),
                    like_count=post.get("likeCount"),
                    reply_count=post.get("replyCount"),
                    view_count=None,
                    raw_json=json.dumps(
                        post, ensure_ascii=False
                    ),
                )

                session.add(social_record)
                saved += 1

    try:
        session.commit()
    except Exception:
        session.rollback()
        raise

    return {
        "source": "bluesky",
        "queries_attempted": len(QUERIES),
        "posts_fetched": fetched,
        "posts_saved": saved,
        "posts_skipped": skipped,
        "errors": errors,
    }
