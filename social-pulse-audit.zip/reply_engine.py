
import json
import os

import httpx

OLLAMA_URL = os.getenv(
    "OLLAMA_URL",
    "http://localhost:11434",
)

REPLY_MODEL = os.getenv(
    "REPLY_MODEL",
    "llama3.1:8b",
)


def generate_reply(
    source: str,
    record_type: str,
    original_text: str,
    topic: str,
    intent: str,
    sentiment: str,
    perception_signal: str,
) -> str:
    prompt = f"""
You are drafting a possible public response for Tata STRIVE.
You are an assistant, not an authorised company spokesperson.

ORIGINAL SOURCE: {source}
CONTENT TYPE: {record_type}
TOPIC: {topic}
INTENT: {intent}
SENTIMENT: {sentiment}
POSSIBLE PERCEPTION SIGNAL: {perception_signal}

ORIGINAL PUBLIC CONTENT:
{original_text[:2500]}

Write one concise, respectful reply draft suitable for the context.

Rules:
- Respond to the actual content, not just its keywords.
- If the author asks a question, address it only when the answer
  is supported by the supplied information.
- Do not invent programmes, eligibility criteria, deadlines,
  placements, statistics, promises, contact details or URLs.
- If an official fact is missing, ask a useful clarification
  or suggest checking an official Tata STRIVE source without
  inventing a link.
- Do not argue, shame the author or dismiss criticism.
- Do not claim to speak officially on behalf of Tata STRIVE.
- Avoid generic promotional replies.
- If the content is unrelated, do not manufacture a response.
- Return only a JSON object with this structure:
  {{"reply_text": "Your proposed reply"}}
"""

    response = httpx.post(
        f"{OLLAMA_URL.rstrip('/')}/api/generate",
        json={
            "model": REPLY_MODEL,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "options": {
                "temperature": 0.3,
                "num_ctx": 2048,
            },
        },
        timeout=180,
    )
    response.raise_for_status()

    data = json.loads(response.json()["response"])
    reply = data.get("reply_text")

    if not isinstance(reply, str) or not reply.strip():
        raise ValueError("Model returned an empty reply draft")

    return reply.strip()
