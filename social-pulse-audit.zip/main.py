from fastapi import HTTPException
from app.ingestion.gdelt import collect_gdelt
from app.ingestion.gnews import collect_gnews
from fastapi import Depends, FastAPI, HTTPException, Query
from app.ingestion.youtube import collect_youtube
from contextlib import asynccontextmanager
from app.ingestion.bluesky import collect_bluesky
from fastapi import Depends, FastAPI, Query
from sqlmodel import Session, select
from sqlmodel import select
from app.models import SocialRecord, RecordAnalysis
from app.analysis_engine import analyse_record
from app.database import engine, get_session, init_db
from app.models import SocialRecord
from app.ingestion.linkedin_scraper import router as linkedin_scraper_router
from fastapi.middleware.cors import CORSMiddleware
import os

from app.models import ReplyDraft, RecordAnalysis, SocialRecord
from app.reply_engine import generate_reply

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="Social Pulse API",
    description="Live social listening and brand perception",
    version="0.1.0",
    lifespan=lifespan,
    
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:4173",
        "http://127.0.0.1:4173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {
        "app": "Social Pulse",
        "status": "running",
    }


@app.get("/health")
def health():
    # Test an actual database connection.
    with engine.connect() as connection:
        connection.exec_driver_sql("SELECT 1")

    return {
        "api": "healthy",
        "database": "connected",
    }


@app.get("/records")
def get_records(
    source: str | None = None,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    session: Session = Depends(get_session),
):
    statement = select(SocialRecord)

    if source:
        statement = statement.where(
            SocialRecord.source == source.lower()
        )

    statement = (
        statement
        .order_by(SocialRecord.collected_at.desc())
        .offset(offset)
        .limit(limit)
    )

    records = session.exec(statement).all()

    return {
        "count": len(records),
        "records": records,
    }


@app.get("/stats")
def get_stats(session: Session = Depends(get_session)):
    records = session.exec(select(SocialRecord)).all()
    analyses = session.exec(select(RecordAnalysis)).all()

    by_source = {}

    for record in records:
        by_source[record.source] = (
            by_source.get(record.source, 0) + 1
        )

    analysis_by_record = {analysis.record_id: analysis for analysis in analyses}
    social_records = [
        record for record in records
        if record.record_type in {"social_post", "comment"}
    ]
    relevant_social = [
        record for record in social_records
        if analysis_by_record.get(record.id)
        and analysis_by_record[record.id].is_relevant
    ]

    return {
        "total_records": len(records),
        "by_source": by_source,
        "total_social_mentions": len(social_records),
        "positive_social_mentions": sum(
            analysis_by_record[record.id].sentiment.lower() == "positive"
            for record in relevant_social
        ),
        "analyzed_relevant_social": len(relevant_social),
        "high_priority_social_mentions": sum(
            analysis_by_record[record.id].priority.lower() in {"high", "critical"}
            for record in relevant_social
        ),
    }


@app.get("/analyses")
def get_analyses(session: Session = Depends(get_session)):
    analyses = session.exec(
        select(RecordAnalysis).order_by(RecordAnalysis.analyzed_at.desc())
    ).all()
    return {
        "count": len(analyses),
        "analyses": analyses,
    }

@app.post("/collect/gnews")
def run_gnews_collection(
    session: Session = Depends(get_session),
):
    try:
        return collect_gnews(session)
    except Exception as exc:
        session.rollback()
        raise HTTPException(
            status_code=502,
            detail=f"GNews collection failed: {type(exc).__name__}: {exc}",
        ) from exc

@app.post("/collect/gdelt")
def run_gdelt_collection(
    session: Session = Depends(get_session),
):
    try:
        return collect_gdelt(session)
    except Exception as exc:
        session.rollback()
        raise HTTPException(
            status_code=502,
            detail=f"GDELT collection failed: {type(exc).__name__}: {exc}",
        ) from exc

@app.post("/collect/youtube")
def run_youtube_collection(
    session: Session = Depends(get_session),
):
    try:
        return collect_youtube(session)
    except Exception as exc:
        session.rollback()
        raise HTTPException(
            status_code=502,
            detail=(
                f"YouTube collection failed: "
                f"{type(exc).__name__}: {exc}"
            ),
        ) from exc

@app.post("/collect/bluesky")
def run_bluesky_collection(
    session: Session = Depends(get_session),
):
    try:
        return collect_bluesky(session)
    except Exception as exc:
        session.rollback()
        raise HTTPException(
            status_code=502,
            detail=(
                f"Bluesky collection failed: "
                f"{type(exc).__name__}: {exc}"
            ),
        ) from exc

@app.post("/collect/all")
def collect_all_sources(
    session: Session = Depends(get_session),
):
    collectors = {
        "gnews": collect_gnews,
        "gdelt": collect_gdelt,
        "youtube": collect_youtube,
        "bluesky": collect_bluesky,
    }

    results = {}

    for source, collector in collectors.items():
        try:
            results[source] = {
                "status": "success",
                "result": collector(session),
            }
        except Exception as exc:
            session.rollback()
            results[source] = {
                "status": "failed",
                "error": f"{type(exc).__name__}: {exc}",
            }

    failed = [
        source
        for source, result in results.items()
        if result["status"] == "failed"
    ]

    return {
        "status": "partial" if failed else "success",
        "sources": results,
        "failed_sources": failed,
    }

@app.post("/analyze/pending")
def analyze_pending_records(
    limit: int = Query(default=10, ge=1, le=30),
    session: Session = Depends(get_session),
):
    records = session.exec(
        select(SocialRecord)
        .order_by(SocialRecord.collected_at.desc())
    ).all()

    existing = session.exec(select(RecordAnalysis)).all()
    analyzed_ids = {item.record_id for item in existing}

    pending = [
        record for record in records
        if record.id not in analyzed_ids
    ][:limit]

    saved = 0
    errors = []

    for record in pending:
        try:
            result = analyse_record(
                source=record.source,
                record_type=record.record_type,
                text=record.text,
            )

            analysis = RecordAnalysis(
                record_id=record.id,
                model_name="phi3:3.8b",
                **result,
            )

            session.add(analysis)
            session.commit()
            saved += 1

        except Exception as exc:
            session.rollback()
            errors.append({
                "record_id": record.id,
                "error": f"{type(exc).__name__}: {exc}",
            })

    return {
        "pending_selected": len(pending),
        "analyses_saved": saved,
        "errors": errors,
    }

@app.post("/replies/generate-pending")
def generate_pending_replies(
    limit: int = Query(default=3, ge=1, le=10),
    session: Session = Depends(get_session),
):
    analyses = session.exec(
        select(RecordAnalysis)
        .order_by(RecordAnalysis.analyzed_at.desc())
    ).all()

    existing = session.exec(select(ReplyDraft)).all()
    drafted_ids = {draft.record_id for draft in existing}

    drafts = []
    errors = []

    for analysis in analyses:
        if len(drafts) >= limit:
            break

        if not analysis.is_relevant:
            continue

        record = session.get(SocialRecord, analysis.record_id)

        if not record or record.id in drafted_ids:
            continue

        # Only draft replies for social content, not news articles.
        if record.record_type not in {"comment", "social_post"}:
            continue

        try:
            reply_text = generate_reply(
                source=record.source,
                record_type=record.record_type,
                original_text=record.text,
                topic=analysis.topic,
                intent=analysis.intent,
                sentiment=analysis.sentiment,
                perception_signal=analysis.perception_signal,
            )

            draft = ReplyDraft(
                record_id=record.id,
                reply_text=reply_text,
                status="draft",
                model_name=os.getenv(
                    "REPLY_MODEL", "llama3.1:8b"
                ),
            )

            session.add(draft)
            session.commit()
            session.refresh(draft)

            drafts.append({
                "draft_id": draft.id,
                "record_id": record.id,
                "source": record.source,
                "original_text": record.text,
                "original_url": record.url,
                "reply_text": draft.reply_text,
                "status": draft.status,
            })

        except Exception as exc:
            session.rollback()
            errors.append({
                "record_id": record.id,
                "error": f"{type(exc).__name__}: {exc}",
            })

    return {
        "drafts_created": len(drafts),
        "drafts": drafts,
        "errors": errors,
    }

from pydantic import BaseModel
from typing import Literal


class ReviewDraftRequest(BaseModel):
    status: Literal["approved", "rejected"]
    edited_reply: str | None = None


@app.get("/replies")
def list_replies(
    status: str | None = None,
    session: Session = Depends(get_session),
):
    statement = select(ReplyDraft)

    if status:
        statement = statement.where(ReplyDraft.status == status)

    drafts = session.exec(
        statement.order_by(ReplyDraft.generated_at.desc())
    ).all()

    results = []

    for draft in drafts:
        record = session.get(SocialRecord, draft.record_id)

        results.append({
            "draft_id": draft.id,
            "record_id": draft.record_id,
            "reply_text": draft.reply_text,
            "status": draft.status,
            "original_text": record.text if record else None,
            "original_url": record.url if record else None,
            "source": record.source if record else None,
            "author": record.author if record else None,
            "published_at": record.published_at if record else None,
            "collected_at": record.collected_at if record else None,
        })

    return results


@app.patch("/replies/{draft_id}/review")
def review_reply(
    draft_id: int,
    request: ReviewDraftRequest,
    session: Session = Depends(get_session),
):
    draft = session.get(ReplyDraft, draft_id)

    if not draft:
        raise HTTPException(
            status_code=404,
            detail="Reply draft not found",
        )

    if draft.status != "draft":
        raise HTTPException(
            status_code=409,
            detail="Only pending drafts can be reviewed",
        )

    if request.edited_reply is not None:
        if not request.edited_reply.strip():
            raise HTTPException(
                status_code=422,
                detail="Edited reply cannot be empty",
            )

        draft.reply_text = request.edited_reply.strip()

    draft.status = request.status
    session.add(draft)
    session.commit()
    session.refresh(draft)

    return {
        "draft_id": draft.id,
        "status": draft.status,
        "reply_text": draft.reply_text,
        "published": False,
    }
