
from datetime import datetime, timezone

from sqlalchemy import UniqueConstraint
from sqlmodel import Field, SQLModel


def utc_now():
    return datetime.now(timezone.utc)


class SocialRecord(SQLModel, table=True):
    __tablename__ = "social_records"

    __table_args__ = (
        UniqueConstraint(
            "source",
            "external_id",
            name="uq_source_external_id",
        ),
    )

    id: int | None = Field(default=None, primary_key=True)

    source: str = Field(index=True)
    record_type: str = Field(index=True)
    external_id: str

    text: str
    url: str | None = None
    author: str | None = None

    published_at: datetime | None = None
    collected_at: datetime = Field(default_factory=utc_now)

    like_count: int | None = None
    reply_count: int | None = None
    view_count: int | None = None

    # Raw API response, serialized as JSON text when available.
    raw_json: str | None = None

class RecordAnalysis(SQLModel, table=True):
    __tablename__ = "record_analyses"

    id: int | None = Field(default=None, primary_key=True)

    record_id: int = Field(
        foreign_key="social_records.id",
        index=True,
        unique=True,
    )

    is_relevant: bool
    relevance_type: str
    topic: str
    intent: str
    sentiment: str
    perception_signal: str
    confidence: float
    priority: str
    rationale: str

    model_name: str
    analyzed_at: datetime = Field(default_factory=utc_now)

class ReplyDraft(SQLModel, table=True):
    __tablename__ = "reply_drafts"

    id: int | None = Field(default=None, primary_key=True)

    record_id: int = Field(
        foreign_key="social_records.id",
        index=True,
        unique=True,
    )

    reply_text: str
    status: str = Field(default="draft", index=True)
    model_name: str
    generated_at: datetime = Field(default_factory=utc_now)
