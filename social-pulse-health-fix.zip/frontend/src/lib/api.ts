export const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000'

export interface SocialRecord {
  id: number
  source: string
  record_type: string
  external_id: string
  text: string
  url?: string | null
  author?: string | null
  published_at?: string | null
  like_count?: number | null
  reply_count?: number | null
  view_count?: number | null
}

export interface RecordAnalysis {
  id: number
  record_id: number
  is_relevant: boolean
  relevance_type: string
  topic: string
  intent: string
  sentiment: string
  perception_signal: string
  confidence: number
  priority: string
  rationale: string
}

export interface ReplyDraft {
  draft_id: number
  record_id: number
  reply_text: string
  status: string
  original_text?: string | null
  original_url?: string | null
  source?: string | null
  author?: string | null
  published_at?: string | null
  collected_at?: string | null
}

export interface Stats {
  total_records: number
  by_source: Record<string, number>
  total_social_mentions?: number
  positive_social_mentions?: number
  analyzed_relevant_social?: number
  high_priority_social_mentions?: number
}

export type OperationResult = Record<string, unknown>

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  let response: Response
  try {
    response = await fetch(`${API_BASE}${path}`, options)
  } catch {
    throw new Error(`Network error: unable to reach the API at ${API_BASE}`)
  }

  if (!response.ok) {
    let detail = `HTTP ${response.status}`
    try {
      const body = (await response.json()) as { detail?: string }
      if (body.detail) detail = body.detail
    } catch {
      // Preserve the HTTP status when the server did not return JSON.
    }
    throw new Error(`${path} failed: ${detail}`)
  }

  try {
    return (await response.json()) as T
  } catch {
    throw new Error(`${path} returned an invalid JSON response`)
  }
}

function listFrom<T>(data: unknown, key: string): T[] {
  if (Array.isArray(data)) return data as T[]
  if (data && typeof data === 'object') {
    const object = data as Record<string, unknown>
    if (Array.isArray(object[key])) return object[key] as T[]
    if (Array.isArray(object.items)) return object.items as T[]
  }
  throw new Error(`API response did not contain a valid ${key} list`)
}

export async function fetchRecords(
  source?: string,
  limit = 100,
  offset = 0,
): Promise<SocialRecord[]> {
  const query = new URLSearchParams({ limit: String(limit), offset: String(offset) })
  if (source) query.set('source', source)
  return listFrom(await request<unknown>(`/records?${query}`), 'records')
}

export async function fetchStats(): Promise<Stats> {
  return request<Stats>('/stats')
}

export async function fetchAnalyses(): Promise<RecordAnalysis[]> {
  return listFrom(await request<unknown>('/analyses'), 'analyses')
}

export async function fetchDrafts(status = 'draft'): Promise<ReplyDraft[]> {
  return listFrom(await request<unknown>(`/replies?status=${encodeURIComponent(status)}`), 'replies')
}

export async function reviewDraft(
  id: number,
  status: 'approved' | 'rejected',
  editedReply?: string,
): Promise<{ draft_id: number; published: false; status: string; reply_text: string }> {
  return request(`/replies/${id}/review`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      status,
      ...(editedReply !== undefined ? { edited_reply: editedReply } : {}),
    }),
  })
}

export function collectAll() {
  return request<OperationResult>('/collect/all', { method: 'POST' })
}
export function collectBluesky() {
  return request<OperationResult>('/collect/bluesky', { method: 'POST' })
}
export function collectYoutube() {
  return request<OperationResult>('/collect/youtube', { method: 'POST' })
}
export function collectGnews() {
  return request<OperationResult>('/collect/gnews', { method: 'POST' })
}
export function collectGdelt() {
  return request<OperationResult>('/collect/gdelt', { method: 'POST' })
}
export function analyzePending() {
  return request<OperationResult>('/analyze/pending', { method: 'POST' })
}
export function generatePendingReplies() {
  return request<OperationResult>('/replies/generate-pending', { method: 'POST' })
}
export interface HealthStatus {
  api: string
  database: string
  ollama: string
  required_models: {
    classifier: boolean
    reply: boolean
  }
  installed_models: string[]
}

export function checkHealth() {
  return request<HealthStatus>('/health')
}
