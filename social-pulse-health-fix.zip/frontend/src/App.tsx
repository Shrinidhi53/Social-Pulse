import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Activity, ArrowUpRight, BarChart3, Bell, CheckCircle2,
  ChevronDown, CircleHelp, Command, ExternalLink, Filter, LayoutDashboard,
  MessageSquare, Radio, RefreshCw, Search, Settings2, ShieldAlert,
  Sparkles, ThumbsUp, XCircle,
} from 'lucide-react'
import {
  analyzePending, checkHealth, collectAll, collectBluesky, collectGdelt,
  collectGnews, collectYoutube, fetchAnalyses, fetchDrafts, fetchRecords,
  fetchStats, generatePendingReplies, reviewDraft,
} from './lib/api'
import type { RecordAnalysis, ReplyDraft, SocialRecord, Stats } from './lib/api'
import './App.css'

const navigation = [
  { label: 'Overview', icon: LayoutDashboard },
  { label: 'Conversations', icon: MessageSquare },
  { label: 'AI Insights', icon: Sparkles },
  { label: 'Reply Center', icon: CheckCircle2 },
  { label: 'Reports', icon: BarChart3 },
]
const sourceFilters = [
  { label: 'All sources', value: '' },
  { label: 'Bluesky', value: 'bluesky' },
  { label: 'YouTube', value: 'youtube' },
  { label: 'News', value: 'news' },
]
const label = (value?: string | null) => value ? value.replace(/_/g, ' ') : '—'
const errorMessage = (reason: unknown) => reason instanceof Error ? reason.message : 'Request failed'

function App() {
  const [activeNav, setActiveNav] = useState('Overview')
  const [activeSource, setActiveSource] = useState('')
  const [search, setSearch] = useState('')
  const [records, setRecords] = useState<SocialRecord[]>([])
  const [analyses, setAnalyses] = useState<RecordAnalysis[]>([])
  const [drafts, setDrafts] = useState<ReplyDraft[]>([])
  const [stats, setStats] = useState<Stats>({ total_records: 0, by_source: {} })
  const [loading, setLoading] = useState(true)
  const [errors, setErrors] = useState<string[]>([])
  const [operation, setOperation] = useState('')
  const [operationMessage, setOperationMessage] = useState('')
  const [healthy, setHealthy] = useState(false)

  const loadDashboard = useCallback(async () => {
    setLoading(true)
    const results = await Promise.allSettled([
      fetchRecords(activeSource === 'news' ? undefined : activeSource || undefined),
      fetchAnalyses(),
      fetchDrafts(),
      fetchStats(),
      checkHealth(),
    ])
    const nextErrors: string[] = []
    if (results[0].status === 'fulfilled') setRecords(results[0].value)
    else nextErrors.push(`Conversations: ${errorMessage(results[0].reason)}`)
    if (results[1].status === 'fulfilled') setAnalyses(results[1].value)
    else nextErrors.push(`AI insights: ${errorMessage(results[1].reason)}`)
    if (results[2].status === 'fulfilled') setDrafts(results[2].value)
    else nextErrors.push(`Reply Center: ${errorMessage(results[2].reason)}`)
    if (results[3].status === 'fulfilled') setStats(results[3].value)
    else nextErrors.push(`Stats: ${errorMessage(results[3].reason)}`)
    if (results[4].status === 'fulfilled') {
      const health = results[4].value
      setHealthy(
        health.ollama === 'connected' &&
        health.required_models.classifier &&
        health.required_models.reply,
      )
    } else setHealthy(false)
    setErrors(nextErrors)
    setLoading(false)
  }, [activeSource])

  useEffect(() => {
    let mounted = true
    loadDashboard().then(() => { if (!mounted) return })
    const timer = window.setInterval(loadDashboard, 30000)
    return () => { mounted = false; window.clearInterval(timer) }
  }, [loadDashboard])

  const analysisByRecord = useMemo(
    () => new Map(analyses.map((analysis) => [analysis.record_id, analysis])),
    [analyses],
  )
  const filteredRecords = useMemo(() => records.filter((record) => {
    const matchesSource = activeSource !== 'news' || ['gnews', 'gdelt'].includes(record.source.toLowerCase())
    const term = search.toLowerCase().trim()
    return matchesSource && (!term || `${record.text} ${record.author || ''} ${record.source}`.toLowerCase().includes(term))
  }), [records, search, activeSource])
  async function runOperation(name: string, action: () => Promise<Record<string, unknown>>) {
    if (operation) return
    setOperation(name); setOperationMessage('')
    try {
      const result = await action()
      setOperationMessage(`${name}: ${JSON.stringify(result)}`)
      await loadDashboard()
    } catch (caught) {
      setOperationMessage(caught instanceof Error ? caught.message : `${name} failed`)
    } finally {
      setOperation('')
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark"><Activity size={22} /></div><div><h1>social pulse</h1><span>LISTENING INTELLIGENCE</span></div></div>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="navigation">{navigation.map(({ label: item, icon: Icon }) => <button key={item} className={`nav-item ${activeNav === item ? 'active' : ''}`} onClick={() => setActiveNav(item)}><Icon size={18} /><span>{item}</span>{item === 'Reply Center' && drafts.length > 0 && <span className="nav-dot" />}</button>)}</nav>
        <div className="sidebar-bottom">
          <div className="system-card"><div className="system-heading"><span className={`status-dot ${healthy ? 'online' : ''}`} /><span>LOCAL AI SYSTEM</span></div><p>Ollama-powered analysis</p><span className="system-caption">{healthy ? 'Ollama + models ready' : 'Ollama or required model unavailable'}</span></div>
          <button className="nav-item"><Settings2 size={18} /><span>Settings</span></button><button className="nav-item"><CircleHelp size={18} /><span>Help & documentation</span></button>
          <div className="profile"><div className="avatar">SP</div><div className="profile-copy"><strong>Social Pulse</strong><span>Project workspace</span></div><ChevronDown size={16} /></div>
        </div>
      </aside>
      <main className="main-content">
        <header className="topbar"><div className="breadcrumbs"><span>Workspace</span><span className="breadcrumb-separator">/</span><strong>{activeNav}</strong></div><div className="topbar-actions"><div className="environment-badge"><span className="status-dot" /> DEVELOPMENT</div><button className="icon-button" aria-label="Refresh" onClick={() => void loadDashboard()}><RefreshCw size={17} /></button><button className="icon-button" aria-label="Notifications"><Bell size={18} /></button><button className="icon-button" aria-label="Commands"><Command size={18} /></button></div></header>
        <div className="page-content">
          <section className="welcome-row"><div><div className="eyebrow"><span className="eyebrow-line" /> SOCIAL INTELLIGENCE PLATFORM</div><h2>Understand the <span>conversation.</span></h2><p className="page-description">Discover what people are saying about skills, employability, and Tata STRIVE.</p></div><button className="primary-button" onClick={() => setActiveNav('Conversations')}><Radio size={16} /> Explore conversations</button></section>
          {errors.length > 0 && <div className="notice-stack">{errors.map((item) => <div className="notice error" key={item}><XCircle size={15} /> {item}</div>)}</div>}
          {operationMessage && <div className="notice"><CheckCircle2 size={15} /> {operationMessage}</div>}
          <section className="metrics-grid">{[
            { metric: 'Total social mentions', value: stats.total_social_mentions != null ? String(stats.total_social_mentions) : '—', note: `Bluesky, YouTube comments · ${stats.total_records} total records`, Icon: MessageSquare },
            { metric: 'Positive sentiment', value: stats.analyzed_relevant_social ? `${Math.round(((stats.positive_social_mentions || 0) / stats.analyzed_relevant_social) * 100)}%` : '—', note: `${stats.positive_social_mentions || 0} of ${stats.analyzed_relevant_social || 0} relevant analyzed`, Icon: ThumbsUp },
            { metric: 'Needs attention', value: stats.high_priority_social_mentions != null ? String(stats.high_priority_social_mentions) : '—', note: 'High-priority relevant social records', Icon: ShieldAlert },
            { metric: 'Pending replies', value: String(drafts.length || (loading ? '…' : '—')), note: 'Awaiting human review', Icon: Activity },
          ].map(({ metric, value, note, Icon }) => <article className="metric-card" key={metric}><div className="metric-top"><span>{metric}</span><div className="metric-icon"><Icon size={17} /></div></div><div className="metric-value">{value}</div><div className="metric-note"><span className="neutral-indicator">—</span>{note}</div></article>)}</section>
          {(activeNav === 'Overview' || activeNav === 'Conversations') && <ConversationPanel records={filteredRecords} totalRecords={records.length} analyses={analysisByRecord} search={search} setSearch={setSearch} activeSource={activeSource} setActiveSource={setActiveSource} loading={loading} />}
          {(activeNav === 'Overview' || activeNav === 'AI Insights') && <Insights analyses={analyses} records={records} />}
          {activeNav === 'Reply Center' && <ReplyCenter drafts={drafts} analyses={analysisByRecord} records={records} onRefresh={loadDashboard} />}
          {activeNav === 'Reports' && <Operations operation={operation} runOperation={runOperation} />}
          {activeNav === 'Overview' && <Operations operation={operation} runOperation={runOperation} />}
          <footer className="page-footer"><span>SOCIAL PULSE <span className="footer-muted">/</span> HACKATHON BUILD</span><span>Evidence first. Action second.</span></footer>
        </div>
      </main>
    </div>
  )
}

function ConversationPanel({ records, totalRecords, analyses, search, setSearch, activeSource, setActiveSource, loading }: { records: SocialRecord[]; totalRecords: number; analyses: Map<number, RecordAnalysis>; search: string; setSearch: (value: string) => void; activeSource: string; setActiveSource: (value: string) => void; loading: boolean }) {
  const emptyTitle = loading ? 'Loading conversations…' : totalRecords === 0 ? 'No records collected yet' : 'No matching conversations'
  const emptyDescription = loading ? 'Fetching evidence from the FastAPI backend.' : totalRecords === 0 ? 'Use the operational controls to collect records from a configured source.' : 'Try another source or search term.'
  return <article className="panel conversation-panel"><div className="panel-header"><div><div className="section-kicker">LIVE MONITORING</div><h3>Conversation stream</h3><p>Public posts, comments, and articles from connected sources</p></div><span className="live-badge"><span className="status-dot" /> {loading ? 'SYNCING' : 'LIVE FEED'}</span></div><div className="feed-toolbar"><div className="source-tabs">{sourceFilters.map((source) => <button key={source.value} className={`source-tab ${activeSource === source.value ? 'selected' : ''}`} onClick={() => setActiveSource(source.value)}><Filter size={14} />{source.label}</button>)}</div><div className="feed-search"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search mentions or authors..." /></div></div><div className="record-list">{records.length ? records.map((record) => <RecordItem key={record.id} record={record} analysis={analyses.get(record.id)} />) : <div className="empty-feed"><div className="empty-icon"><Radio size={24} /></div><h4>{emptyTitle}</h4><p>{emptyDescription}</p></div>}</div><div className="panel-footer"><span>DATA SOURCE: FASTAPI</span><span>RECORDS: {records.length}{totalRecords !== records.length ? ` of ${totalRecords}` : ''}</span></div></article>
}

function RecordItem({ record, analysis }: { record: SocialRecord; analysis?: RecordAnalysis }) {
  return <div className="record-item"><div className="record-meta"><span className="source-chip">{record.source} · {record.record_type}</span><span>{record.published_at ? new Date(record.published_at).toLocaleString() : 'Date unavailable'}</span></div><p>{record.text}</p><div className="record-details"><span>{record.author || 'Unknown author'}</span><span>Sentiment: {label(analysis?.sentiment)}</span><span>Topic: {label(analysis?.topic)}</span><span>Priority: {label(analysis?.priority)}</span>{record.like_count != null && <span>♥ {record.like_count}</span>}{record.reply_count != null && <span>↩ {record.reply_count}</span>}{record.view_count != null && <span>◉ {record.view_count}</span>}{record.url && <a href={record.url} target="_blank" rel="noopener noreferrer">Open <ExternalLink size={12} /></a>}</div></div>
}

function Insights({ analyses, records }: { analyses: RecordAnalysis[]; records: SocialRecord[] }) {
  const relevant = analyses.filter((analysis) => analysis.is_relevant)
  const top = (values: string[]) => Object.entries(values.reduce<Record<string, number>>((counts, value) => { counts[value] = (counts[value] || 0) + 1; return counts }, {})).sort((a, b) => b[1] - a[1]).slice(0, 3)
  return <article className="panel insights-card"><div className="panel-header compact"><div className="insight-title"><div className="ai-icon"><Sparkles size={17} /></div><div><div className="section-kicker">LOCAL AI</div><h3>Pulse intelligence</h3></div></div></div><div className="insight-body"><p className="sample-note">Derived from {relevant.length} relevant analyses across {records.length} records. This is a sample, not a measure of the entire public.</p>{relevant.length ? <><InsightRow title="Sentiment" items={top(relevant.map((item) => item.sentiment))} /><InsightRow title="Topics" items={top(relevant.map((item) => item.topic))} /><InsightRow title="Intent" items={top(relevant.map((item) => item.intent))} /><InsightRow title="Priority concerns" items={top(relevant.filter((item) => ['high', 'critical'].includes(item.priority.toLowerCase())).map((item) => item.rationale))} /></> : <p className="muted">No analyzed evidence yet. Run “Analyze pending” below.</p>}</div></article>
}
function InsightRow({ title, items }: { title: string; items: [string, number][] }) { return <div className="insight-row"><strong>{title}</strong><span>{items.length ? items.map(([item, count]) => `${label(item)} (${count})`).join(' · ') : 'Insufficient data'}</span></div> }

function ReplyCenter({ drafts, analyses, records, onRefresh }: { drafts: ReplyDraft[]; analyses: Map<number, RecordAnalysis>; records: SocialRecord[]; onRefresh: () => Promise<void> }) {
  const [busy, setBusy] = useState<number | null>(null)
  const [edited, setEdited] = useState<Record<number, string>>({})
  const [message, setMessage] = useState('')
  async function review(draft: ReplyDraft, status: 'approved' | 'rejected') {
    const text = edited[draft.draft_id] ?? draft.reply_text
    if (!text.trim()) { setMessage('Reply text cannot be empty.'); return }
    setBusy(draft.draft_id); setMessage('')
    try { const result = await reviewDraft(draft.draft_id, status, text); setMessage(`${status} successfully. Published: ${String(result.published)}`); await onRefresh() } catch (error) { setMessage(error instanceof Error ? error.message : 'Review failed') } finally { setBusy(null) }
  }
  return <article className="panel reply-panel"><div className="panel-header"><div><div className="section-kicker">HUMAN REVIEW</div><h3>Reply center</h3><p>Approve or reject drafts; approval never publishes automatically.</p></div></div>{message && <div className="notice">{message}</div>}{drafts.length ? drafts.map((draft) => { const record = records.find((item) => item.id === draft.record_id); const analysis = analyses.get(draft.record_id); const source = draft.source || record?.source || 'Unknown source'; const originalUrl = draft.original_url || record?.url; return <div className="draft-card" key={draft.draft_id}><div className="record-meta"><span className="source-chip">{source} · {record?.record_type || 'post'}</span><span>Status: {label(draft.status)}</span><span>Author: {draft.author || record?.author || 'Unknown author'}</span></div><p className="original-text">{draft.original_text || record?.text || 'Original text unavailable'}</p><div className="record-details"><span>Sentiment: {label(analysis?.sentiment)}</span><span>Priority: {label(analysis?.priority)}</span>{originalUrl && <a href={originalUrl} target="_blank" rel="noopener noreferrer">View original <ExternalLink size={12} /></a>}</div><label className="reply-label" htmlFor={`reply-${draft.draft_id}`}>AI-generated reply</label><textarea id={`reply-${draft.draft_id}`} value={edited[draft.draft_id] ?? draft.reply_text} onChange={(event) => setEdited({ ...edited, [draft.draft_id]: event.target.value })} aria-label="Edit reply" /><div className="draft-actions"><button className="secondary-button" disabled={busy === draft.draft_id} onClick={() => void review(draft, 'rejected')}>{busy === draft.draft_id ? 'Saving…' : 'Reject'}</button><button className="primary-button" disabled={busy === draft.draft_id} onClick={() => void review(draft, 'approved')}>{busy === draft.draft_id ? 'Saving…' : 'Approve'}</button><span className="publish-note">Approval is review-only; publishing is disabled.</span></div></div> }) : <div className="empty-feed"><h4>No pending drafts</h4><p>Generate drafts from analyzed relevant social records.</p></div>}</article>
}

function Operations({ operation, runOperation }: { operation: string; runOperation: (name: string, action: () => Promise<Record<string, unknown>>) => Promise<void> }) {
  const actions = [['Collect all sources', collectAll], ['Collect Bluesky', collectBluesky], ['Collect YouTube', collectYoutube], ['Collect GNews', collectGnews], ['Collect GDELT', collectGdelt], ['Analyze pending', analyzePending], ['Generate reply drafts', generatePendingReplies]] as const
  return <article className="panel operations-panel"><div className="panel-header"><div><div className="section-kicker">OPERATIONS</div><h3>Ingestion & analysis controls</h3><p>These actions run only when explicitly requested.</p></div></div><div className="operation-grid">{actions.map(([name, action]) => <button key={name} className="operation-button" disabled={Boolean(operation)} onClick={() => void runOperation(name, action)}>{operation === name ? <RefreshCw className="spin" size={15} /> : <ArrowUpRight size={15} />}{name}</button>)}</div></article>
}

export default App
